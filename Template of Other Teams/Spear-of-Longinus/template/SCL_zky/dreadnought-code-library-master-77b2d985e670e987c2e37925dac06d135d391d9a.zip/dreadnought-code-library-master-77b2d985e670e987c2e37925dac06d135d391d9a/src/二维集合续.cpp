#include <cstdio>
#include <cmath>
#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
}