\begin{lstlisting}
vector<int> KMP()
{
	vector<int> ans;
	nxt[0] = -1;
	nxt[1] = 0;
	for(int i = 2; i <= m; i++)
	{
		nxt[i] = nxt[i - 1];
		while(nxt[i] >= 0 and st[i] != st[nxt[i] + 1])
			nxt[i] = nxt[nxt[i]];
		nxt[i]++;
	}
	for(int i = 1, p = 1; i <= n; i++)
	{
		while(p and str1[i] != st[p])
			p = nxt[p - 1] + 1;
		p++;
		if(p == m + 1) p = nxt[m] + 1, ans.push_back(i - m);
	}
	return ans;
}
\end{lstlisting}
