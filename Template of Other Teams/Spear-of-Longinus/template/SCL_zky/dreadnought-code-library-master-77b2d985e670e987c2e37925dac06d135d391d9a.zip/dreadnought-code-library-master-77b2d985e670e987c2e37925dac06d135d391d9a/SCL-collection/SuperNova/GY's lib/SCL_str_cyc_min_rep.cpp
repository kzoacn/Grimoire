\begin{lstlisting}
struct cyc_string
{
	int n, offset;
	char str[max_length];
	char & operator [] (int x)
	{return str[((offset + x) % n)];}
	cyc_string(){offset = 0;}
};
void minimum_circular_representation(cyc_string & a)
{
	int i = 0, j = 1, dlt = 0, n = a.n;
	while(i < n and j < n and dlt < n)
	{
	  if(a[i + dlt] == a[j + dlt]) dlt++;
	  else
	  {
	    if(a[i + dlt] > a[j + dlt]) i += dlt + 1; else j += dlt + 1;
	    dlt = 0;
	  }
	}
	a.offset = min(i, j);
}
int main()
{return 0;}
\end{lstlisting}
